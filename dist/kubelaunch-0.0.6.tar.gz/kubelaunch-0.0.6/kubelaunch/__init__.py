"""Helper package for running """
__version__ = '0.0.6'
